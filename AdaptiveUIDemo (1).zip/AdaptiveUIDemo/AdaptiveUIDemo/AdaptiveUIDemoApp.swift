//
//  AdaptiveUIDemoApp.swift
//  AdaptiveUIDemo
//
//  Created by Medhat Elmasry on 2026-11-06.
//

import SwiftUI

@main
struct AdaptiveUIDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
