//
//  AdaptiveFormsView.swift
//  AdaptiveUIDemo
//
//  Created by Medhat Elmasry on 2026-11-06.
//

import SwiftUI

struct AdaptiveFormsView: View {
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
       
       @State private var firstName = ""
       @State private var lastName = ""
       @State private var email = ""
       var body: some View {

           Form {
               Section("Student Information") {
                   if horizontalSizeClass == .regular {
                       HStack {
                           TextField("First Name", text: $firstName)
                           TextField("Last Name", text: $lastName)
                       }
                   } else {
                       TextField("First Name", text: $firstName)
                       TextField("Last Name", text: $lastName)
                   }
                   TextField("Email", text: $email)
               }
               Button("Register Student") { }
           }
       }
}

#Preview {
    AdaptiveFormsView()
}
