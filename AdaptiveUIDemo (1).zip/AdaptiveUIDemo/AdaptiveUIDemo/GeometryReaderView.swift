//
//  GeometryReaderView.swift
//  AdaptiveUIDemo
//
//  Created by Medhat Elmasry on 2026-11-06.
//

import SwiftUI

struct GeometryReaderView: View {
    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 20) {
                
                Text("Width: \(Int(geometry.size.width))")
                    .font(.title)
                
                Rectangle()
                    .fill(geometry.size.width > 500 ? .green : .red)
                    .frame(
                        width: geometry.size.width * 0.8,
                        height: 100
                    )
                
                Text(
                    geometry.size.width > 500
                    ? "Large Screen"
                    : "Small Screen"
                )
                .font(.headline)
                
                AsyncImage(url: URL(string: "https://picsum.photos/300")) { image in
                    image
                        .resizable()
                        .scaledToFit()
                } placeholder: {
                    ProgressView()
                }
                .frame(width: geometry.size.width * 0.5)
                
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }
    
}

#Preview {
    GeometryReaderView()
}
