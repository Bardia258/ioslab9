//
//  ViewThatFitsView.swift
//  AdaptiveUIDemo
//
//  Created by Medhat Elmasry on 2026-11-06.
//

import SwiftUI

struct ViewThatFitsView: View {
    var body: some View {

           ViewThatFits {

               // First choice: Horizontal layout
               HStack {
                   Button("Add Course") { }

                   Button("Edit Course") { }

                   Button("Delete Course") { }
               }
               .buttonStyle(.borderedProminent)

               // Second choice: Vertical layout
               VStack {
                   Button("Add Course") { }

                   Button("Edit Course") { }

                   Button("Delete Course") { }
               }
               .buttonStyle(.borderedProminent)
           }
           .padding()
       }

}

#Preview {
    ViewThatFitsView()
}
