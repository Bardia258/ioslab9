//
//  NavAdaptView.swift
//  AdaptiveUIDemo
//
//  Created by Medhat Elmasry on 2026-11-06.
//

import SwiftUI

struct NavAdaptView: View {
    let courses = [
        "Java",
        "Algorithms",
        "Databases",
        "Math"
    ]

    @State private var selectedCourse: String?

    var body: some View {

        NavigationSplitView {

            List(courses,
                 id: \.self,
                 selection: $selectedCourse) { course in

               NavigationLink(value: course) {
                  Text(course)
               }
            }

        } detail: {

            if let selectedCourse {
                VStack {
                    Image(systemName: "book.fill")
                        .font(.system(size: 80))

                    Text(selectedCourse)
                        .font(.largeTitle)

                    Text("Course Details")
                }
            } else {
                Text("Select a course")
            }
        }
    }

}

#Preview {
    NavAdaptView()
}
