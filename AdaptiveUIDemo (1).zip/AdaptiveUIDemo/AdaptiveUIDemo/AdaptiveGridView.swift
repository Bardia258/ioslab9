//
//  AdaptiveGridView.swift
//  AdaptiveUIDemo
//
//  Created by Medhat Elmasry on 2026-11-06.
//

import SwiftUI

struct Product: Identifiable {
    let id = UUID()
    let name: String
}

struct AdaptiveGridView: View {

    let products = [
        Product(name: "Apples"),
        Product(name: "Peaches"),
        Product(name: "Bananas"),
        Product(name: "Tangerines"),
        Product(name: "Mangos"),
        Product(name: "Grapes"),
        Product(name: "Oranges"),
        Product(name: "Pears"),
        Product(name: "Pineapples"),
        Product(name: "Cherries"),
        Product(name: "Blueberries"),
        Product(name: "Appricots")
    ]

    let columns = [
        GridItem(.adaptive(minimum: 120))
    ]

    var body: some View {

        ScrollView {

            LazyVGrid(columns: columns, spacing: 20) {

                ForEach(products) { product in

                    VStack {
                        Image(systemName: "shippingbox")
                            .font(.system(size: 40))

                        Text(product.name)
                            .font(.headline)
                    }
                    .frame(height: 120)
                    .frame(maxWidth: .infinity)
                    .background(.blue.opacity(0.2))
                    .cornerRadius(12)
                }
            }
            .padding()
        }
    }

}

#Preview {
    AdaptiveGridView()
}
